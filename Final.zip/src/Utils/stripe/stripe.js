import { loadStripe } from "@stripe/stripe-js";


export const stripePromise = loadStripe(
  "pk_test_51MtER1JPzZLXXuizaPCUMWxbVzi3JqfwTZ5QftDqAgrITtumfcyRU2zGJPUqEng9ztzwmNepPPYGdZxqMgnPsuk400a10nOmoo"
);
